"""
test_agent.py  --  STUB. Claude Code expands this. See INITIAL_PROMPT.md.

Drive agentcore_demo.agent.Agent with the FakeBackend fixture and assert the emitted
event stream is well-formed. One starter test is provided; add coverage for
each question and for the receipt total.
"""

from agentcore_demo.agent import Agent


def test_run_emits_a_well_formed_stream(backend, meter):
    events: list[dict] = []
    Agent(backend, meter, events.append).run()

    types = [e["type"] for e in events]
    assert types[-1] == "done"
    assert "receipt" in types
    assert types.count("question") == 3

    receipt = next(e for e in events if e["type"] == "receipt")
    assert receipt["total"] == round(sum(r["usd"] for r in receipt["rows"]), 4)

    # TODO (Claude Code): assert each question emits its model events in order,
    # that Q2 emits a `chart`, and that Q3 runs both Opus and Nova.
