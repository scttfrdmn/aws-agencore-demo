"""
app.py  --  STUB. Claude Code builds this. See INITIAL_PROMPT.md.

Target: a FastAPI app that
  - GET /          serves static/index.html
  - GET /static/*  serves static assets
  - WS  /ws        runs Agent over all three questions and forwards every
                   emitted event to the client as JSON (see the event
                   protocol in agent.py / CLAUDE.md)
  - opens http://HOST:PORT in the browser on startup

The agent's emit(event) callback should push events onto the WebSocket.
Inject AwsBackend(REGION, KB_ID, MODELS) for the real run; tests inject a fake.

Run with:  python -m agentcore_demo.app
"""

raise NotImplementedError("Claude Code: build app.py -- see INITIAL_PROMPT.md")
