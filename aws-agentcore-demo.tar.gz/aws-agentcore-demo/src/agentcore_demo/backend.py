"""
backend.py  --  the Backend interface.

The agent depends on this Protocol, not on AWS. agentcore_demo.aws.AwsBackend implements
it for real; tests provide a fake with the same three methods. Keeping the
interface here (no boto3 import) means the agent and the whole test suite
import cleanly with no AWS dependency.
"""

from __future__ import annotations

from typing import Protocol


class Backend(Protocol):
    """What agent.py needs from the world. Real impl + test fakes satisfy it."""

    def retrieve(self, query: str, n: int = 12) -> list[dict]:
        """Semantic search; returns dicts with text / source / score."""
        ...

    def converse(
        self, tier: str, system: str, prompt: str, max_tokens: int = 1600
    ) -> tuple[str, dict]:
        """One model call; returns (text, usage) where usage has *Tokens fields."""
        ...

    def code_interpreter_run(self, code: str) -> tuple[str, float]:
        """Run code in a sandbox; returns (stdout, wall_clock_seconds)."""
        ...
