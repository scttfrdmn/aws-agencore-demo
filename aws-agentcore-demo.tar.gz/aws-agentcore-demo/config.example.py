"""
config.example.py  --  copy to config.py and fill in.

    cp config.example.py config.py

config.py is git-ignored. Never commit real account IDs, bucket names,
or knowledge-base IDs.
"""

# --- account / region ---------------------------------------------------
REGION = "us-west-2"  # region where KB, Bedrock models, S3 Vectors,
# and AgentCore Code Interpreter all live
ACCOUNT_ID = "000000000000"
BUCKET = "your-corpus-bucket"  # S3 bucket holding the paper corpus
CORPUS_PREFIX = "corpus/"

# --- filled in by build_kb.py (paste its output back here) --------------
KB_ID = ""
DATA_SOURCE_ID = ""

# --- resource names build_kb.py will CREATE -----------------------------
KB_NAME = "inside-the-lines-pcsk9"
KB_ROLE_NAME = "inside-the-lines-kb-role"
VECTOR_BUCKET_NAME = "inside-the-lines-vectors"  # S3 Vectors bucket
VECTOR_INDEX_NAME = "inside-the-lines-index"

# --- models -------------------------------------------------------------
# Verify the Claude + Nova inference-profile IDs against your account:
#   aws bedrock list-inference-profiles --region us-west-2
MODELS = {
    "haiku": "us.anthropic.claude-haiku-4-5-20251001-v1:0",
    "sonnet": "us.anthropic.claude-sonnet-4-6-v1:0",
    "opus": "us.anthropic.claude-opus-4-6-v1:0",
    "nova": "us.amazon.nova-pro-v1:0",  # the non-Claude cross-check
}
EMBED_MODEL_ID = "amazon.titan-embed-text-v2:0"
EMBED_DIM = 1024  # must match the vector index

# --- pricing ------------------------------------------------------------
# USD per 1,000,000 tokens (input, output).
# PLACEHOLDERS -- confirm against the live Bedrock pricing page. The cost
# receipt is only as honest as these numbers.
PRICING = {
    "haiku": (0.80, 4.00),
    "sonnet": (3.00, 15.00),
    "opus": (15.00, 75.00),
    "nova": (0.80, 3.20),
}
CODE_INTERPRETER_PER_SECOND = 0.0000  # set from current AgentCore pricing

# --- web app ------------------------------------------------------------
HOST = "127.0.0.1"
PORT = 8000
