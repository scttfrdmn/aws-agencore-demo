"""
aws.py  --  the AWS backend for the demo.

One class, AwsBackend, wrapping the three things the agent needs:
  retrieve()             -> Bedrock Knowledge Bases
  converse()             -> Bedrock model invocation (Claude + Nova)
  code_interpreter_run() -> AgentCore Code Interpreter

The agent depends on this class by injection, so tests can pass a fake with
the same three methods and never touch the cloud (see tests/conftest.py).

API shapes here were verified against current AWS docs -- do not "fix" them
without checking.
"""

from __future__ import annotations

import time

import boto3

from agentcore_demo.backend import Backend

__all__ = ["AwsBackend", "Backend"]


class AwsBackend:
    """Real AWS implementation of Backend."""

    def __init__(self, region: str, kb_id: str, models: dict[str, str]):
        self.region = region
        self.kb_id = kb_id
        self.models = models
        self._kb = boto3.client("bedrock-agent-runtime", region_name=region)
        self._llm = boto3.client("bedrock-runtime", region_name=region)

    def retrieve(self, query: str, n: int = 12) -> list[dict]:
        """Semantic search over the Bedrock Knowledge Base."""
        resp = self._kb.retrieve(
            knowledgeBaseId=self.kb_id,
            retrievalQuery={"text": query},
            retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": n}},
        )
        return [
            {
                "text": item["content"]["text"],
                "source": item.get("location", {}).get("s3Location", {}).get("uri", "?"),
                "score": item.get("score", 0.0),
            }
            for item in resp["retrievalResults"]
        ]

    def converse(
        self, tier: str, system: str, prompt: str, max_tokens: int = 1600
    ) -> tuple[str, dict]:
        """One Bedrock converse call. Works uniformly for Claude and Nova."""
        resp = self._llm.converse(
            modelId=self.models[tier],
            system=[{"text": system}],
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": max_tokens, "temperature": 0.2},
        )
        text = resp["output"]["message"]["content"][0]["text"]
        return text, resp["usage"]

    def code_interpreter_run(self, code: str) -> tuple[str, float]:
        """Execute code in an isolated AgentCore Code Interpreter microVM."""
        from bedrock_agentcore.tools.code_interpreter_client import CodeInterpreter

        ci = CodeInterpreter(self.region)
        ci.start()
        t0 = time.time()
        try:
            resp = ci.invoke("executeCode", {"language": "python", "code": code})
            out: list[str] = []
            for event in resp["stream"]:
                for block in event.get("result", {}).get("content", []):
                    if block.get("type") == "text":
                        out.append(block["text"])
            return "\n".join(out), time.time() - t0
        finally:
            ci.stop()
