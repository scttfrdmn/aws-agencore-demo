"""
agent.py  --  the demo orchestration.

Runs the three locked questions against a Backend, and reports progress by
calling an emit(event: dict) callback. The web app (app.py) provides an emit
that pushes each event over a WebSocket; a test or CLI can provide an emit
that just collects them.

This module is the source of truth for the event protocol -- see CLAUDE.md
for the table, and EVENT TYPES below.
"""

from __future__ import annotations

import base64
import re
from collections.abc import Callable, Sequence

from agentcore_demo import questions as Q
from agentcore_demo.backend import Backend
from agentcore_demo.cost import CostMeter

Emit = Callable[[dict], None]

# EVENT TYPES (every event is a dict with a "type" key):
#   question  {n, text}                  a new question started
#   phase     {label}                    status line
#   retrieval {count}                    N passages retrieved
#   model     {tier, label, state, ...}  state="start" | "done" (+usage,cost)
#   answer    {title, text}              a synthesis / adjudication result
#   code      {text}                     generated analysis code
#   chart     {data}                     base64 PNG, for an inline <img>
#   cost      {total}                    running cost-meter total
#   receipt   {rows, total}              the final itemised receipt
#   done      {}                         run complete


class Agent:
    """Drives the three-question demo and emits events as it goes."""

    def __init__(self, backend: Backend, meter: CostMeter, emit: Emit):
        self.backend = backend
        self.meter = meter
        self.emit = emit

    # -- helpers ---------------------------------------------------------
    def _context(self, chunks: list[dict]) -> str:
        return "\n\n".join(f"[source: {c['source']}]\n{c['text']}" for c in chunks)

    def _model(
        self, step: str, tier: str, label: str, system: str, prompt: str, max_tokens: int = 1600
    ) -> str:
        """Run one model call, emitting start/done events and metering cost."""
        self.emit({"type": "model", "tier": tier, "label": label, "state": "start"})
        text, usage = self.backend.converse(tier, system, prompt, max_tokens)
        cost = self.meter.add_llm(step, tier, label, usage)
        self.emit(
            {
                "type": "model",
                "tier": tier,
                "label": label,
                "state": "done",
                "usage": {
                    "inputTokens": usage.get("inputTokens", 0),
                    "outputTokens": usage.get("outputTokens", 0),
                },
                "cost": round(cost, 4),
            }
        )
        self.emit({"type": "cost", "total": round(self.meter.total, 4)})
        return text

    # -- Q1: friction gone -- Haiku reads and cites ----------------------
    def question_1(self) -> None:
        self.emit({"type": "question", "n": 1, "text": Q.QUESTIONS[0]})
        self.emit({"type": "phase", "label": "retrieving from the knowledge base"})
        chunks = self.backend.retrieve(Q.QUESTIONS[0])
        self.emit({"type": "retrieval", "count": len(chunks)})
        text = self._model(
            "Q1  synthesis",
            "haiku",
            "Claude Haiku",
            Q.SYNTHESIS_SYSTEM,
            f"Passages:\n{self._context(chunks)}\n\nQuestion: {Q.QUESTIONS[0]}",
        )
        self.emit({"type": "answer", "title": "Cited synthesis  ·  Claude Haiku", "text": text})

    # -- Q2: real work -- Sonnet writes code, Code Interpreter runs it ---
    def question_2(self) -> None:
        self.emit({"type": "question", "n": 2, "text": Q.QUESTIONS[1]})
        self.emit({"type": "phase", "label": "retrieving trial data"})
        chunks = self.backend.retrieve(Q.QUESTIONS[1], n=16)
        code = self._model(
            "Q2  code generation",
            "sonnet",
            "Claude Sonnet",
            Q.CODEGEN_SYSTEM,
            f"Passages:\n{self._context(chunks)}",
            max_tokens=2200,
        )
        code = re.sub(r"^```[a-z]*\n?|```$", "", code.strip(), flags=re.M)
        self.emit({"type": "code", "text": code})
        self.emit({"type": "phase", "label": "running in AgentCore Code Interpreter"})
        stdout, seconds = self.backend.code_interpreter_run(code)
        self.meter.add_compute("Q2  analysis run", seconds)
        self.emit({"type": "cost", "total": round(self.meter.total, 4)})
        chart, clean = self._extract_chart(stdout)
        if chart:
            self.emit({"type": "chart", "data": chart})
        self.emit({"type": "answer", "title": "Code Interpreter output  ·  microVM", "text": clean})

    # -- Q3: the hard call -- Opus AND Nova, then adjudicate -------------
    def question_3(self) -> None:
        self.emit({"type": "question", "n": 3, "text": Q.QUESTIONS[2]})
        self.emit({"type": "phase", "label": "retrieving"})
        chunks = self.backend.retrieve(Q.QUESTIONS[2], n=16)
        prompt = f"Passages:\n{self._context(chunks)}\n\n{Q.QUESTIONS[2]}"
        review_a = self._model("Q3  reading", "opus", "Claude Opus", Q.REVIEW_SYSTEM, prompt, 2000)
        review_b = self._model(
            "Q3  reading", "nova", "Amazon Nova Pro", Q.REVIEW_SYSTEM, prompt, 2000
        )
        adjudication = self._model(
            "Q3  adjudication",
            "sonnet",
            "Claude Sonnet",
            Q.ADJUDICATE_SYSTEM,
            f"REVIEW A (Claude Opus):\n{review_a}\n\nREVIEW B (Amazon Nova Pro):\n{review_b}",
            1600,
        )
        self.emit(
            {"type": "answer", "title": "Two model families, cross-checked", "text": adjudication}
        )

    # -- run ------------------------------------------------------------
    def run(self, which: Sequence[int] = (1, 2, 3)) -> None:
        steps = {1: self.question_1, 2: self.question_2, 3: self.question_3}
        for n in which:
            steps[n]()
        self.emit({"type": "receipt", **self.meter.receipt()})
        self.emit({"type": "done"})

    @staticmethod
    def _extract_chart(stdout: str) -> tuple[str | None, str]:
        """Pull a base64 PNG printed by the generated code; return (data, rest)."""
        m = re.search(r"CHART_B64:([A-Za-z0-9+/=]+)", stdout)
        if not m:
            return None, stdout.strip()
        base64.b64decode(m.group(1))  # validate it decodes
        return m.group(1), stdout.replace(m.group(0), "").strip()
