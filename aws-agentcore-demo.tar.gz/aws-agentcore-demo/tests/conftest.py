"""
conftest.py  --  shared test fixtures.

The key fixture is FakeBackend: it satisfies the same interface as
agentcore_demo.aws.AwsBackend (the Backend protocol) but returns canned data, so the whole
suite runs with no AWS credentials and no network. Tests for agent.py and the
web app should use it.
"""

import re

import pytest

from agentcore_demo.cost import CostMeter

# Realistic-ish placeholder pricing for deterministic cost assertions.
TEST_PRICING = {
    "haiku": (0.80, 4.00),
    "sonnet": (3.00, 15.00),
    "opus": (15.00, 75.00),
    "nova": (0.80, 3.20),
}

# A valid 1x1 PNG, base64 -- enough to exercise the chart path.
_PNG_1x1 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgAAIAAAUAAXpeqz8AAAAASUVORK5CYII="
)


class FakeBackend:
    """Canned implementation of the Backend protocol -- no AWS, no network."""

    def __init__(self):
        self.calls: list[str] = []

    def retrieve(self, query: str, n: int = 12) -> list[dict]:
        self.calls.append(f"retrieve:{query[:20]}")
        return [
            {
                "text": f"Passage {i} about PCSK9 and LDL.",
                "source": f"s3://demo/PMC{1000 + i}.txt",
                "score": 0.9 - i * 0.01,
            }
            for i in range(min(n, 6))
        ]

    def converse(self, tier, system, prompt, max_tokens=1600):
        self.calls.append(f"converse:{tier}")
        usage = {"inputTokens": 12_000, "outputTokens": 1_000}
        if tier == "sonnet" and "self-contained Python" in system:
            # codegen path -- return a tiny script that prints a chart
            code = f"import io, base64\nprint('CHART_B64:{_PNG_1x1}')"
            return code, usage
        return f"[{tier}] answer to: {prompt[:40]}", usage

    def code_interpreter_run(self, code: str) -> tuple[str, float]:
        """Simulate running the code: echo whatever CHART_B64 it would print."""
        self.calls.append("code_interpreter")
        m = re.search(r"CHART_B64:([A-Za-z0-9+/=]+)", code)
        return (f"CHART_B64:{m.group(1)}" if m else "ran ok"), 2.5


@pytest.fixture
def backend() -> FakeBackend:
    return FakeBackend()


@pytest.fixture
def meter() -> CostMeter:
    return CostMeter(pricing=TEST_PRICING, ci_per_second=0.0)
