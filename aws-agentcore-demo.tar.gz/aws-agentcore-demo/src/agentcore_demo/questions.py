"""
questions.py  --  the three locked demo questions and their system prompts.

These are rehearsed for the live talk. DO NOT reword them.
The escalation across the three is the demo: cheap model -> workhorse ->
the hard call cross-checked by two model families.
"""

SUBJECT = "PCSK9"

QUESTIONS = [
    "What is the established role of PCSK9 in LDL-cholesterol regulation?",
    "Compare the reported LDL-lowering effects across the clinical trials in "
    "this corpus, and chart them.",
    "Where does the literature disagree about the off-target or adverse "
    "effects of PCSK9 inhibition, and what should be tested next?",
]

# System prompt for Q1 -- cited synthesis (Claude Haiku).
SYNTHESIS_SYSTEM = (
    "You are a biomedical research assistant. Answer ONLY from the provided "
    "passages. Cite every claim inline as [source: ...]."
)

# System prompt for Q2 -- analysis code generation (Claude Sonnet).
# The generated code runs in AgentCore Code Interpreter; it must end by
# printing the chart as base64 so the web UI can render it inline.
CODEGEN_SYSTEM = (
    "You write self-contained Python for data analysis. Use only matplotlib, "
    "numpy, pandas. Extract the trial names and reported LDL-lowering "
    "percentages from the passages, build a DataFrame, and produce a "
    "horizontal bar chart. End the script with exactly:\n"
    "  import io, base64\n"
    "  buf = io.BytesIO()\n"
    "  plt.savefig(buf, format='png', dpi=140, bbox_inches='tight')\n"
    "  print('CHART_B64:' + base64.b64encode(buf.getvalue()).decode())\n"
    "Output ONLY the code -- no prose, no markdown fences."
)

# System prompt for Q3 -- independent expert reading (Claude Opus AND Nova Pro).
REVIEW_SYSTEM = (
    "You are a careful biomedical reviewer. From ONLY these passages, identify "
    "points of genuine disagreement about off-target / adverse effects, and "
    "propose concrete next experiments. Cite inline."
)

# System prompt for Q3 -- adjudicating the two independent readings (Sonnet).
ADJUDICATE_SYSTEM = (
    "Compare two expert reviews of the same evidence, produced by two different "
    "AI model families. State where they AGREE, where they DISAGREE, and which "
    "disagreements are the highest-value next experiments. Be concise."
)
