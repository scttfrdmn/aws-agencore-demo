#!/usr/bin/env python3
"""
build_kb.py  --  one-time, fully scripted Knowledge Base provisioning.

Uses Amazon S3 Vectors as the vector store: serverless, pay-per-use, no hourly
floor, no OpenSearch collection to manage. Steps:

  1. IAM role the knowledge base assumes
  2. an S3 Vectors bucket + vector index
  3. the Bedrock Knowledge Base + an S3 data source
  4. an ingestion job that embeds and indexes every paper

Run once, before the talk. Prints the KB id + data-source id for config.py.
Tear it down afterwards with teardown.py.

>>> VERIFY BEFORE RUNNING <<<
S3 Vectors is a recent service. The `s3vectors` client method names and the
`create_knowledge_base` storageConfiguration shape for S3 Vectors are the
newest APIs in this repo. Check current boto3 docs and adjust the two spots
marked  # VERIFY  below. Everything else (IAM, bedrock-agent KB/data-source/
ingestion) is stable.

Requires: boto3
"""

import json
import time

import boto3

import config as cfg

iam = boto3.client("iam")
agent = boto3.client("bedrock-agent", region_name=cfg.REGION)
s3v = boto3.client("s3vectors", region_name=cfg.REGION)  # VERIFY: service name


# ----------------------------------------------------------------------
# 1. IAM role for the knowledge base
# ----------------------------------------------------------------------
def create_kb_role() -> str:
    trust = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "bedrock.amazonaws.com"},
                "Action": "sts:AssumeRole",
            }
        ],
    }
    try:
        arn = iam.create_role(
            RoleName=cfg.KB_ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust),
            Description="Inside the Lines demo -- Bedrock KB execution role",
        )["Role"]["Arn"]
    except iam.exceptions.EntityAlreadyExistsException:
        arn = iam.get_role(RoleName=cfg.KB_ROLE_NAME)["Role"]["Arn"]

    policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": [f"arn:aws:s3:::{cfg.BUCKET}", f"arn:aws:s3:::{cfg.BUCKET}/*"],
            },
            {
                "Effect": "Allow",
                "Action": "bedrock:InvokeModel",
                "Resource": f"arn:aws:bedrock:{cfg.REGION}::foundation-model/{cfg.EMBED_MODEL_ID}",
            },
            # VERIFY: scope s3vectors actions per current S3 Vectors IAM reference.
            {"Effect": "Allow", "Action": "s3vectors:*", "Resource": "*"},
        ],
    }
    iam.put_role_policy(
        RoleName=cfg.KB_ROLE_NAME, PolicyName="kb-access", PolicyDocument=json.dumps(policy)
    )
    print(f"  IAM role: {arn}")
    time.sleep(10)  # let the role propagate
    return arn


# ----------------------------------------------------------------------
# 2. S3 Vectors bucket + index
# ----------------------------------------------------------------------
def create_vector_store() -> str:
    # VERIFY: confirm create_vector_bucket / create_index signatures.
    try:
        s3v.create_vector_bucket(vectorBucketName=cfg.VECTOR_BUCKET_NAME)
        print(f"  vector bucket: {cfg.VECTOR_BUCKET_NAME}")
    except Exception as e:  # noqa: BLE001 -- already-exists is fine
        print(f"  vector bucket: {type(e).__name__} (continuing)")
    try:
        s3v.create_index(
            vectorBucketName=cfg.VECTOR_BUCKET_NAME,
            indexName=cfg.VECTOR_INDEX_NAME,
            dataType="float32",
            dimension=cfg.EMBED_DIM,
            distanceMetric="cosine",
        )
        print(f"  vector index: {cfg.VECTOR_INDEX_NAME}")
    except Exception as e:  # noqa: BLE001
        print(f"  vector index: {type(e).__name__} (continuing)")
    return (
        f"arn:aws:s3vectors:{cfg.REGION}:{cfg.ACCOUNT_ID}:"
        f"bucket/{cfg.VECTOR_BUCKET_NAME}/index/{cfg.VECTOR_INDEX_NAME}"
    )


# ----------------------------------------------------------------------
# 3. Knowledge base + data source
# ----------------------------------------------------------------------
def create_kb(role_arn: str, index_arn: str) -> tuple[str, str]:
    embed_arn = f"arn:aws:bedrock:{cfg.REGION}::foundation-model/{cfg.EMBED_MODEL_ID}"
    # VERIFY: storageConfiguration shape for S3 Vectors against current boto3.
    kb = agent.create_knowledge_base(
        name=cfg.KB_NAME,
        roleArn=role_arn,
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            "vectorKnowledgeBaseConfiguration": {"embeddingModelArn": embed_arn},
        },
        storageConfiguration={
            "type": "S3_VECTORS",
            "s3VectorsConfiguration": {"indexArn": index_arn},
        },
    )
    kb_id = kb["knowledgeBase"]["knowledgeBaseId"]
    ds = agent.create_data_source(
        knowledgeBaseId=kb_id,
        name="pmc-corpus",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {
                "bucketArn": f"arn:aws:s3:::{cfg.BUCKET}",
                "inclusionPrefixes": [cfg.CORPUS_PREFIX],
            },
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {"maxTokens": 512, "overlapPercentage": 15},
            }
        },
    )
    return kb_id, ds["dataSource"]["dataSourceId"]


# ----------------------------------------------------------------------
# 4. Ingestion
# ----------------------------------------------------------------------
def ingest(kb_id: str, ds_id: str) -> None:
    job_id = agent.start_ingestion_job(knowledgeBaseId=kb_id, dataSourceId=ds_id)["ingestionJob"][
        "ingestionJobId"
    ]
    print("  ingestion started -- embedding + indexing every paper...")
    while True:
        st = agent.get_ingestion_job(
            knowledgeBaseId=kb_id, dataSourceId=ds_id, ingestionJobId=job_id
        )["ingestionJob"]
        print(f"    status: {st['status']}")
        if st["status"] in ("COMPLETE", "FAILED"):
            if st["status"] == "COMPLETE":
                s = st.get("statistics", {})
                print(
                    f"    indexed {s.get('numberOfNewDocumentsIndexed')} "
                    f"of {s.get('numberOfDocumentsScanned')} documents"
                )
            break
        time.sleep(15)


if __name__ == "__main__":
    print("1/4  IAM role")
    role_arn = create_kb_role()
    print("2/4  S3 Vectors bucket + index")
    index_arn = create_vector_store()
    print("3/4  knowledge base + data source")
    kb_id, ds_id = create_kb(role_arn, index_arn)
    print("4/4  ingestion")
    ingest(kb_id, ds_id)
    print("\nDone. Paste these into config.py:")
    print(f'  KB_ID = "{kb_id}"')
    print(f'  DATA_SOURCE_ID = "{ds_id}"')
    print("\nRun teardown.py after the talk.")
