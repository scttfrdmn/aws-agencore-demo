#!/usr/bin/env python3
"""
teardown.py  --  delete everything build_kb.py created.

S3 Vectors is pay-per-use, so there is no hourly meter to race -- but tear it
down anyway to keep the account clean. Removes: the knowledge base, the S3
Vectors index + bucket, and the IAM role. The S3 corpus bucket is left alone.
"""

import boto3

import config as cfg

agent = boto3.client("bedrock-agent", region_name=cfg.REGION)
s3v = boto3.client("s3vectors", region_name=cfg.REGION)
iam = boto3.client("iam")


def _try(label, fn):
    try:
        fn()
        print(f"  deleted: {label}")
    except Exception as e:  # noqa: BLE001 -- teardown is best-effort
        print(f"  skip ({label}): {type(e).__name__}")


if __name__ == "__main__":
    if cfg.KB_ID:
        _try(
            f"knowledge base {cfg.KB_ID}",
            lambda: agent.delete_knowledge_base(knowledgeBaseId=cfg.KB_ID),
        )

    _try(
        f"vector index {cfg.VECTOR_INDEX_NAME}",
        lambda: s3v.delete_index(
            vectorBucketName=cfg.VECTOR_BUCKET_NAME, indexName=cfg.VECTOR_INDEX_NAME
        ),
    )
    _try(
        f"vector bucket {cfg.VECTOR_BUCKET_NAME}",
        lambda: s3v.delete_vector_bucket(vectorBucketName=cfg.VECTOR_BUCKET_NAME),
    )

    def drop_role():
        for p in iam.list_role_policies(RoleName=cfg.KB_ROLE_NAME)["PolicyNames"]:
            iam.delete_role_policy(RoleName=cfg.KB_ROLE_NAME, PolicyName=p)
        iam.delete_role(RoleName=cfg.KB_ROLE_NAME)

    _try(f"IAM role {cfg.KB_ROLE_NAME}", drop_role)
    print("\nDone.")
